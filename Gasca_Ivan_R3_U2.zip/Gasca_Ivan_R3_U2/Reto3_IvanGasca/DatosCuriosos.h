//
//

#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>
@interface DatosCuriosos : NSObject

@property (nonatomic, strong) NSString *titulo;
@property (nonatomic, strong) NSString *texto;
@property (nonatomic, strong) UIImage *imagen;

@end

