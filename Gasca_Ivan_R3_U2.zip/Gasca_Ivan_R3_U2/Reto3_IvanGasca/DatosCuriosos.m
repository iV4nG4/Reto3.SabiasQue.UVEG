//
//

// DatosCuriosos.m
#import "DatosCuriosos.h"
#import <UIKit/UIKit.h>
@implementation DatosCuriosos

@end
