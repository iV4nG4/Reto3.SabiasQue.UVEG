//
//  ViewController.m
//

#import "ViewController.h"
#import <UIKit/UIKit.h>
@interface ViewController ()
@property (nonatomic, strong) NSMutableDictionary *datosPorCategoria;
@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Inicializa el diccionario con datos curiosos
    self.datosPorCategoria = [NSMutableDictionary dictionary];
    // Oculta los elementos por defecto
    self.Dato_Cat.hidden = YES;
    self.Dato_text.hidden = YES;
    self.Dato_image.hidden = YES;
    // Datos curiosos para la categoría de educación
    DatosCuriosos *educacion1 = [DatosCuriosos new];
    educacion1.titulo = @"El Titanic no fue el primero que usó el ‘SOS’";
    educacion1.texto = @"La señal de auxilio se estableció en Berlín, el 3 de octubre de 1906. Se introdujo formalmente en 1908. Se utilizó por primera vez el 10 de julio de 1909, cuando la embarcación RMS Slavonia encalló y se hundió en las inmediaciones de las Azores. El hundimiento del Titanic le dio más popularidad.";
    educacion1.imagen = [UIImage imageNamed:@"educacion1.jpg"];
    
    DatosCuriosos *educacion2 = [DatosCuriosos new];
    educacion2.titulo = @"Pez Murcielago";
    educacion2.texto = @"El Pez murciélago (lophiiformes ) utiliza sus aletas pélvicas modificadas para caminar a lo largo del lecho marino como torpes sapos en busca de gusanos y otros animales pequeños.";
    educacion2.imagen = [UIImage imageNamed:@"educacion2.jpg"];
    
    DatosCuriosos *educacion3 = [DatosCuriosos new];
    educacion3.titulo = @"Oymyakon";
    educacion3.texto = @" Oymyakon es el lugar habitado más frío del planeta. Es conocido como “la fábrica de invierno”. En los días de invierno solo hay tres horas de luz.";
    educacion3.imagen = [UIImage imageNamed:@"educacion3.jpg"];
    
    // Agrega los datos curiosos de educación al diccionario
    [self.datosPorCategoria setObject:@[educacion1, educacion2, educacion3] forKey:@"educacion"];

    // Datos curiosos para la categoría de arte
    DatosCuriosos *arte1 = [DatosCuriosos new];
    arte1.titulo = @"Robo de la Mona Lisa:";
    arte1.texto = @"La Mona Lisa se hizo más famosa después de ser robada en 1911, Pablo Picasso fue arrestado como sospechoso.";
    arte1.imagen = [UIImage imageNamed:@"arte1.jpg"];
    
    DatosCuriosos *arte2 = [DatosCuriosos new];
    arte2.titulo = @"Leonardo Da Vinci";
    arte2.texto = @"Leonardo Da Vinci tenía la capacidad de escribir con una mano y dibujar con la otra al mismo tiempo. Dibujaba con la derecha y con la izquierda escribía.";
    arte2.imagen = [UIImage imageNamed:@"arte2.jpg"];
    
    DatosCuriosos *arte3 = [DatosCuriosos new];
    arte3.titulo = @"Libro de Records Guinness";
    arte3.texto = @"El libro Guinness World Records tiene el récord de ser el libro más robado de las bibliotecas públicas. Curioso, ¿verdad?";
    arte3.imagen = [UIImage imageNamed:@"arte3.jpg"];
    
    // Agrega los datos curiosos de arte al diccionario
    [self.datosPorCategoria setObject:@[arte1, arte2, arte3] forKey:@"arte"];
    
    // Datos curiosos para la categoría de deportivo
    DatosCuriosos *deportes1 = [DatosCuriosos new];
    deportes1.titulo = @"Futbol Americano NFL";
    deportes1.texto = @"El fútbol americano de la NFL tiene una duración promedio de 3 horas y media. Sin embargo, el tiempo en que los jugadores están en movimiento detrás del balón o de sus contrincantes, es de alrededor de 11 minutos.";
    deportes1.imagen = [UIImage imageNamed:@"deportes1.jpg"];
    
    DatosCuriosos *deportes2 = [DatosCuriosos new];
    deportes2.titulo = @"Pelotas de Tenis";
    deportes2.texto = @"¿Las pelotas de tenis, son amarillas o verdes? Bueno, antes las pelotas de tenis eran de color negro o blanco, pero las pelotas amarillas se introdujeron en 1972 para hacerlas más visibles para los televidentes.";
    deportes2.imagen = [UIImage imageNamed:@"deportes2.jpg"];
    
    DatosCuriosos *deportes3 = [DatosCuriosos new];
    deportes3.titulo = @"Los juegos olímpicos no se detienen ante una masacre.";
    deportes3.texto = @"En 1972, un grupo terrorista palestino conocido como «Septiembre Negro» irrumpió en la sede de los juegos olímpicos en Múnich, secuestrando a 11 competidores israelíes. Al no concederse las demandas de los terroristas, las víctimas fueron salvajemente masacradas, pese a esto, los juegos no se detuvieron. Perturbador…";
    deportes3.imagen = [UIImage imageNamed:@"deportes3.jpg"];
    
    // Agrega los datos curiosos de deportes al diccionario
    [self.datosPorCategoria setObject:@[deportes1, deportes2, deportes3] forKey:@"deportes"];
}
- (IBAction)Sport_button:(id)sender {
    NSLog(@"Botón de Deportes presionado");
    [self mostrarDatosParaCategoria:@"deportes"];
}

- (IBAction)Art_button:(id)sender {
    NSLog(@"Botón de Arte presionado");
    [self mostrarDatosParaCategoria:@"arte"];
}

- (IBAction)Education_button:(id)sender {
    NSLog(@"Botón de Educacion presionado");
    [self mostrarDatosParaCategoria:@"educacion"];
}

- (void)mostrarDatosParaCategoria:(NSString *)categoria {
    NSLog(@"Antes de obtener datos: %@", self.datosPorCategoria);
    // Obtén los datos curiosos para la categoría actual
    NSArray *datosCuriosos = [self.datosPorCategoria objectForKey:categoria];
    
    if (datosCuriosos.count > 0) {
        // Obtiene el primer dato curioso de la lista
        DatosCuriosos *datoCurioso = [datosCuriosos firstObject];
        
        // Actualiza la interfaz con los datos curiosos
        self.Dato_Cat.text = datoCurioso.titulo;
        self.Dato_text.text = datoCurioso.texto;
        self.Dato_image.image = datoCurioso.imagen;
        
        // Muestra los elementos con datos
        self.Dato_Cat.hidden = NO;
        self.Dato_text.hidden = NO;
        self.Dato_image.hidden = NO;
        
        // Mueve el primer dato al final de la lista para mostrar el siguiente en la próxima vez
        NSMutableArray *mutableDatosCuriosos = [datosCuriosos mutableCopy];
        [mutableDatosCuriosos removeObjectAtIndex:0];
        
        // Agrega el siguiente dato curioso al final de la lista
        if (mutableDatosCuriosos.count > 0) {
            DatosCuriosos *siguienteDatoCurioso = [mutableDatosCuriosos firstObject];
            [mutableDatosCuriosos addObject:siguienteDatoCurioso];
        }
        
        [self.datosPorCategoria setObject:mutableDatosCuriosos forKey:categoria];
    }
}

@end
